class Teacher: 
   def setid(self, id): 
      self.id = id 
   def getid(self): 
      return self.id 
   def setname(self, name): 
      self.name = name 
   def getname(self): 
      return self.name 
   def setaddress(self, address): 
      self.address = address 
   def getaddress(self): 
      return self.address
   def setsalary(self, salary): 
      self.salary = salary 
   def getsalary(self): 
      return self.salary

